

------------SQL Server Mathematical functions ---------------

SELECT SQRT(..value..)
SELECT PI()
SELECT SQUARE(..value..)
SELECT ROUND(..value.., number_of_decimal_places)
SELECT CEILING(..value..)
SELECT FLOOR(..value..)

------------SQL Server Mathematical functions ---------------





-----------------------------SQL | Conversion Functions--------------


------------------------------Implicit Data-Type Conversion :

FROM				TO
VARCHAR2 or CHAR	NUMBER
VARCHAR2 or CHAR	DATE
DATE				VARCHAR2
NUMBER				VARCHAR2

SELECT employee_id,first_name,salary FROM employees WHERE salary > 15000;
SELECT employee_id,first_name,salary FROM employees WHERE salary > '15000';

-------------------------------Implicit Data-Type Conversion :



-----------------------------------Explicit Data-Type Conversion :


----------------Using the TO_CHAR Function with Dates :

TO_CHAR(date, ’format_model’)
SELECT employee_id, TO_CHAR(hire_date, ’MM/YY’) Month_Hired FROM employees WHERE last_name = ’Higgins’;

-----Elements of the Date Format Model :
YYYY	Full year in Numbers
YEAR	Year spelled out
MM		Two digit value for month
MONTH	Full name of the month
MON		Three Letter abbreviation of the month
DY		Three letter abbreviation of the day of the week
DAY		Full Name of the of the week
DD		Numeric day of the month

-----Date Format Elements – Time Formats :
AM or PM			Meridian indicater
A.M. or P.M.		Meridian indicater with periods
HH or HH12 or HH24	Hour of day,or hour (1-12),or hour (0-23)
MI					Minute 0-59
SS					Second 0-59
SSSSS				Second past Mid Night 0-86399

-----Other Formats :
/ . ,		Punctuation is reproduced in the result
“of the”	Quoted string is reproduced in the result

-----Specifying Suffixes to Influence Number Display :
TH				Ordinal Number (for example DDTH for 4TH
SP				Spelled out number (for example DDSP for FOUR
SPTH or THSP	spelled out ordinal numbers (for example DDSPTH for FOURTH

SELECT last_name,TO_CHAR(hire_date, ’fmDD Month YYYY’) AS HIREDATE FROM employees;



-----------------------Using the TO_CHAR Function with Numbers  :

TO_CHAR(number, ’format_model’)

------format elements to display a number value as a character :
9	Represent a number
0	Forces a zero to be displayed
$	places a floating dollar sign
L	Uses the floating local currency symbol
.	Print a decimal point
,	Prints a Thousand indicator

SELECT TO_CHAR(salary, ’$99,999.00’) SALARY FROM employees WHERE last_name = ’Ernst’;



---------------------Using the TO_NUMBER and TO_DATE Functions :

TO_NUMBER(char[, ’format_model’])
TO_DATE(char[, ’format_model’])

SELECT last_name, hire_date FROM employees WHERE hire_date = TO_DATE(’May 24, 1999’, ’fxMonth DD, YYYY’);


--------------------------------------------Explicit Data-Type Conversion :


-----------------------------------------------SQL | Conversion Functions--------------------------






----------------------------------SQL general functions-----------------------------

NVL (expr1, expr2)
SELECT  salary, NVL(commission_pct, 0),(salary*12) + (salary*12*NVL(commission_pct, 0))annual_salary FROM employees;

NVL2 (expr1, expr2, expr3)
SELECT last_name, salary, commission_pct,NVL2(commission_pct, ’SAL+COMM’, ’SAL’)income FROM employees;

DECODE(col|expression, search1, result1 [, search2, result2,...,][, default])
SELECT last_name, job_id, salary,DECODE(job_id, ’IT_PROG’, 1.10*salary,’ST_CLERK’, 1.15*salary,’SA_REP’, 1.20*salary,salary) REVISED_SALARY FROM employees;

COALESCE (expr_1, expr_2, ... expr_n)
SELECT last_name, COALESCE(commission_pct, salary, 10) comm FROM employees ORDER BY commission_pct;

NULLIF (expr_1, expr_2)
SELECT LENGTH(first_name) "expr1",LENGTH(last_name) "expr2",NULLIF(LENGTH(first_name),LENGTH(last_name))result FROM employees;

LNNVL( condition(s) )
SELECT COUNT(*) FROM employees WHERE commission_pct < .2; 
SELECT COUNT(*) FROM employees WHERE LNNVL(commission_pct >= .2); 

NANVL( n1 , n2 )
SELECT bin_float, NANVL(bin_float,0) FROM nanvl_demo;

----------------------------------SQL general functions-----------------------------





----------------------------------SQL | Conditional Expressions----------------------------------


CASE expr WHEN comparison_expr1 THEN return_expr1
         [WHEN comparison_expr2 THEN return_expr2
          .
          .
          .
          WHEN comparison_exprn THEN return_exprn
          ELSE else_expr]
END

SELECT first_name, dpartment_id, salary,
       CASE dpartment_id WHEN 50 THEN 1.5*salary
                         WHEN 12 THEN 2.0*salary
       ELSE salary
       END "REVISED SALARY"
FROM Employee;

------------------------------------------------------------

DECODE(col/expression, search1, result1
                        [, search2, result2,........,]
                        [, default])
						
SELECT first_name, dpartment_id, salary,
       DECODE(dpartment_id, 50, 1.5*salary,
                             12, 2.0*salary,
              salary)
       "REVISED SALARY"
FROM Employee;

-------------------------------------------------------------

COALESCE(value [, ......] )

SELECT COALESCE(last_name, '- NA -')
from Employee;

-------------------------------------------------------------

GREATEST(expr1, expr2 [, .....] )

SELECT GREATEST('XYZ', 'xyz')
from dual;
SELECT GREATEST('XYZ', null, 'xyz')
from dual;

-------------------------------------------------------------

IFNULL(expr1, expr2)

SELECT IFNULL(1,0) 
FROM dual;

-------------------------------------------------------------

WHERE column IN (x1, x2, x3 [,......] )

SELECT * from Employee
WHERE dpartment_id IN(50, 12);

-------------------------------------------------------------

LEAST(expr1, expr2 [, ......])

SELECT LEAST('XYZ', 'xyz')
from dual;

-------------------------------------------------------------

NULLIF(value1, value2)

SELECT NULLIF(9995463931, contact_num) 
from Employee;

-------------------------------------------------------------


----------------------------------SQL | Conditional Expressions----------------------------------





----------------------------------SQL | Character Functions----------------------------------


-----------Case-Manipulative Functions:

LOWER(SQL course)
Input1: SELECT LOWER('GEEKSFORGEEKS') FROM DUAL;
Output1: geeksforgeeks
Input2: SELECT LOWER('DATABASE@456') FROM DUAL;
Output2: database@456

UPPER(SQL course)
Input1: SELECT UPPER('geeksforgeeks') FROM DUAL;
Output1: GEEKSFORGEEKS
Input2: SELECT UPPER('dbms$508%7') FROM DUAL;
Output2: DBMS$508%7

INITCAP(SQL course)
Input1: SELECT INITCAP('geeksforgeeks is a computer science portal for geeks') FROM DUAL;
Output1: Geeksforgeeks Is A Computer Science Portal For Geeks 
Input2: SELECT INITCAP('PRACTICE_CODING_FOR_EFFICIENCY') FROM DUAL;
Output2: Practice_Coding_For_Efficiency


-------------Character-Manipulative Functions:

CONCAT('String1', 'String2')
Input1: SELECT CONCAT('computer' ,'science') FROM DUAL;
Output1: computerscience
Input2: SELECT CONCAT( NULL ,'Android') FROM DUAL;
Output2: Android 
Input3: SELECT CONCAT( NULL ,NULL ) FROM DUAL;
Output3: - 

LENGTH(Column|Expression)
Input1: SELECT LENGTH('Learning Is Fun') FROM DUAL;
Output1: 15 
Input2: SELECT LENGTH('   Write an Interview  Experience ') FROM DUAL;
Output2: 34
Input3: SELECT LENGTH('') FROM DUAL; or SELECT LENGTH( NULL ) FROM DUAL;
Output3: - 

SUBSTR('String',start-index,length_of_extracted_string)
Input1: SELECT SUBSTR('Database Management System', 9) FROM DUAL;
Output1: Management System
Input2: SELECT SUBSTR('Database Management System', 9, 7) FROM DUAL;
Output2: Manage

INSTR(Column|Expression, 'String', [,m], [n])
Input: SELECT INSTR('Google apps are great applications','app',1,2) FROM DUAL;
Output: 23 

LPAD(Column|Expression, n, 'String')
Input1: SELECT LPAD('100',5,'*') FROM DUAL;
Output1: **100
Input2: SELECT LPAD('hello', 21, 'geek') FROM DUAL;
Output2: geekgeekgeekgeekhello

RPAD(Column|Expression, n, 'String')
Input1: SELECT RPAD('5000',7,'*') FROM DUAL;
Output1: 5000*** 
Input1: SELECT RPAD('earn', 19, 'money') FROM DUAL;
Output1: earnmoneymoneymoney

TRIM(Leading|Trailing|Both, trim_character FROM trim_source)
Input1: SELECT TRIM('G' FROM 'GEEKS') FROM DUAL;
Output1: EEKS
Input2: SELECT TRIM('        geeksforgeeks   ') FROM DUAL; 
Output2:geeksforgeeks

REPLACE(Text, search_string, replacement_string)
Input1: SELECT REPLACE('DATA MANAGEMENT', 'DATA','DATABASE') FROM DUAL;
Output1: DATABASE MANAGEMENT 
Input2: SELECT REPLACE('abcdeabcccabdddeeabcc', 'abc') FROM DUAL;            
Output2: deccabdddeec

----------------------------------SQL | Character Functions----------------------------------



----------------------------------SQL | Date Functions---------------------------------------

ADDDATE(): It returns a date after a certain time/date interval has been added.
Syntax: SELECT ADDTIME("2018-07-16 02:52:47", "2");
Output: 2018-07-16 02:52:49

ADDTIME(): It returns a time / date time after a certain time interval has been added.
Syntax: SELECT ADDTIME("2017-06-15 09:34:21", "2");
Output: 2017-06-15 09:34:23

CURDATE(): It returns the current date.
Syntax: SELECT CURDATE();
Output: 2018-07-16

CURRENT_DATE(): It returns the current date.
Syntax: SELECT CURRENT_DATE();
Output: 2018-07-16

CURRENT_TIME(): It returns the current time.
Syntax: SELECT CURRENT_TIME();
Output: 02:53:15

CURRENT_TIMESTAMP(): It returns the current date and time.
Syntax: SELECT CURRENT_TIMESTAMP();
Output: 2018-07-16 02:53:21

CURTIME(): It returns the current time.
Syntax: SELECT CURTIME();
Output: 02:53:28

DATE(): It extracts the date value from a date or date time expression.
Syntax: SELECT DATE("2017-06-15");
Output: 2017-06-15

DATEDIFF(): It returns the difference in days between two date values.
Syntax: SELECT DATEDIFF("2017-06-25", "2017-06-15");
Output: 10

DATE_ADD(): It returns a date after a certain time/date interval has been added.
Syntax: SELECT DATE_ADD("2018-07-16", INTERVAL 10 DAY);
Output: 2018-07-16

DATE_FORMAT(): It formats a date as specified by a format mask.
Syntax: SELECT DATE_FORMAT("2018-06-15", "%Y");
Output: 2018

DATE_SUB(): It returns a date after a certain time/date interval has been subtracted.
Syntax: SELECT DATE_SUB("2017-06-15", INTERVAL 10 DAY);
Output: 2018-07-16

DAY(): It returns the day portion of a date value.
Syntax: SELECT DAY("2018-07-16");
Output: 16

DAYNAME(): It returns the weekday name for a date.
Syntax: SELECT DAYNAME('2008-05-15');
Output: Thursday

DAYOFMONTH(): It returns the day portion of a date value.
Syntax: SELECT DAYOFMONTH('2018-07-16');
Output: 16

DAYWEEK(): It returns the weekday index for a date value.
Syntax: SELECT WEEKDAY("2018-07-16");
Output: 0

DAYOFYEAR(): It returns the day of the year for a date value.
Syntax: SELECT DAYOFYEAR("2018-07-16");
Output: 197

EXTRACT(): It extracts parts from a date.
Syntax: SELECT EXTRACT(MONTH FROM "2018-07-16");
Output: 7

FROM_DAYS(): It returns a date value from a numeric representation of the day.
Syntax: SELECT FROM_DAYS(685467);
Output: 1876-09-29

HOUR(): It returns the hour portion of a date value.
Syntax: SELECT HOUR("2018-07-16 09:34:00");
Output: 9

LAST_DAY(): It returns the last day of the month for a given date.
Syntax: SELECT LAST_DAY('2018-07-16');
Output: 2018-07-31

LOCALTIME(): It returns the current date and time.
Syntax: SELECT LOCALTIME();
Output: 2018-07-16 02:56:42

LOCALTIMESTAMP(): It returns the current date and time.
Syntax: SELECT LOCALTIMESTAMP();
Output: 2018-07-16 02:56:48

MAKEDATE(): It returns the date for a certain year and day-of-year value.
Syntax: SELECT MAKEDATE(2009, 138);
Output: 2009-05-18

MAKETIME(): It returns the time for a certain hour, minute, second combination.
Syntax: SELECT MAKETIME(11, 35, 4);
Output: 11:35:04

MICROSECOND(): It returns the microsecond portion of a date value.
Syntax: SELECT MICROSECOND("2018-07-18 09:12:00.000345");
Output: 345

MINUTE(): It returns the minute portion of a date value.
Syntax: SELECT MINUTE("2018-07-18 09:12:00");
Output: 12

MONTH(): It returns the month portion of a date value.
Syntax: SELECT MONTH ('2018/07/18')AS MONTH;
Output: 7

MONTHNAME(): It returns the full month name for a date.
Syntax: SELECT MONTHNAME("2018/07/18");
Output: JULY

NOW(): It returns the current date and time.
Syntax: SELECT NOW();
Output: 2018-07-18 09:14:32

PERIOD_ADD(): It takes a period and adds a specified number of months to it.
Syntax: SELECT PERIOD_ADD(201803, 6);
Output: 201809

PERIOD_DIFF(): It returns the difference in months between two periods.
Syntax: SELECT PERIOD_DIFF(201810, 201802);
Output: 8

QUARTER(): It returns the quarter portion of a date value.
Syntax: SELECT QUARTER("2018/07/18");
Output: 3

SECOND(): It returns the second portion of a date value.
Syntax: SELECT SECOND("09:14:00:00032");
Output: 0

SEC_TO_TIME(): It converts numeric seconds into a time value.
Syntax: SELECT SEC_TO_TIME(1);
Output: 00:00:01

STR_TO_DATE(): It takes a string and returns a date specified by a format mask.
Syntax:  SELECT STR_TO_DATE("JULY 18 2018", "%M %D %Y");
Output: 0018-07-18

SUBDATE(): It returns a date after which a certain time/date interval has been subtracted.
Syntax: SELECT SUBDATE("2017-06-15", INTERVAL 10 DAY);
Output: 2017-06-05

SUBTIME(): It returns a time/date time value after a certain time interval has been subtracted.
Syntax: SELECT SUBDATE("2018/07/18", INTERVAL 10 DAY);
Output: 2018-07-18 09:15:17.542768

SYSDATE(): It returns the current date and time.
Syntax: SELECT SYSDATE();
Output: 2018-07-18 09:19:03

TIME(): It extracts the time value from a time/date time expression.
Syntax: SELECT TIME("09:16:10");
Output: 09:16:10

TIME_FORMAT(): It formats the time as specified by a format mask.
Syntax: SELECT TIME_FORMAT("09:16:10", "%H %I %S");
Output: 09 09 10

TIME_TO_SEC(): It converts a time value into numeric seconds.
Syntax: SELECT TIME_TO_SEC("09:16:10");
Output: 33370

TIMEDIFF(): It returns the difference between two time/datetime values.
Syntax: SELECT TIMEDIFF("09:16:10", "09:16:04");
Output: 00:00:06

TIMESTAMP(): It converts an expression to a date time value and if specified adds an optional time interval to the value.
Syntax: SELECT TIMESTAMP("2018-07-18", "09:16:10");
Output: 2018-07-18 09:16:10

TO_DAYS(): It converts a date into numeric days.
Syntax: SELECT TO_DAYS("2018-07-18");
Output: 737258

WEEK(): It returns the week portion of a date value.
Syntax: SELECT WEEK("2018-07-18");
Output: 28

WEEKDAY(): It returns the weekday index for a date value.
Syntax: SELECT WEEKDAY("2018-07-18");
Output: 2

WEEKOFYEAR(): It returns the week of the year for a date value.
Syntax: SELECT WEEKOFYEAR("2018-07-18");
Output: 29

YEAR(): It returns the year portion of a date value.
Syntax: SELECT YEAR("2018-07-18");
Output: 2018

YEARWEEK(): It returns the year and week for a date value.
Syntax:  SELECT YEARWEEK("2018-07-18");
Output: 201828

--------------------------------SQL | Date Functions--------------------------------------------------


--------------------------------SQL | Functions (Aggregate and Scalar Functions)----------------------

Aggregate functions:
These functions are used to do operations from the values of the column and a single value is returned.
AVG()
COUNT()
FIRST()
LAST()
MAX()
MIN()
SUM()
Scalar functions:
These functions are based on user input, these too returns single value.

UCASE()
LCASE()
MID()
LEN()
ROUND()
NOW()
FORMAT()

-------------------------SQL | Functions (Aggregate and Scalar Functions)------------------------




--------------------------SQL | Numeric Functions------------------------------

Numeric Functions are used to perform operations on numbers and return numbers.
Following are the numeric functions defined in SQL:

ABS(): It returns the absolute value of a number.
Syntax: SELECT ABS(-243.5);
Output: 243.5

SQL> SELECT ABS(-10);
+--------------------------------------+
| ABS(10)                                                  
+--------------------------------------+
| 10                                                       
+--------------------------------------+
ACOS(): It returns the cosine of a number.
Syntax:  SELECT ACOS(0.25);
Output: 1.318116071652818

ASIN(): It returns the arc sine of a number.
Syntax: SELECT ASIN(0.25);
Output: 0.25268025514207865

ATAN(): It returns the arc tangent of a number.
Syntax: SELECT ATAN(2.5);
Output: 1.1902899496825317

CEIL(): It returns the smallest integer value that is greater than or equal to a number.
Syntax: SELECT CEIL(25.75);
Output: 26

CEILING(): It returns the smallest integer value that is greater than or equal to a number.
Syntax: SELECT CEILING(25.75);
Output: 26

COS(): It returns the cosine of a number.
Syntax: SELECT COS(30);
Output: 0.15425144988758405

COT(): It returns the cotangent of a number.
Syntax: SELECT COT(6);
Output: -3.436353004180128

DEGREES(): It converts a radian value into degrees.
Syntax: SELECT DEGREES(1.5);
Output: 85.94366926962348



SQL>SELECT DEGREES(PI());
+------------------------------------------+
| DEGREES(PI())                                           
+------------------------------------------+
| 180.000000                                              
+------------------------------------------+
DIV(): It is used for integer division.
Syntax: SELECT 10 DIV 5;
Output: 2

EXP(): It returns e raised to the power of number.
Syntax: SELECT EXP(1);
Output: 2.718281828459045

FLOOR(): It returns the largest integer value that is less than or equal to a number.
Syntax: SELECT FLOOR(25.75);
Output: 25

GREATEST(): It returns the greatest value in a list of expressions.
Syntax: SELECT GREATEST(30, 2, 36, 81, 125);
Output: 125

LEAST(): It returns the smallest value in a list of expressions.
Syntax: SELECT LEAST(30, 2, 36, 81, 125);
Output: 2

LN(): It returns the natural logarithm of a number.
Syntax: SELECT LN(2);
Output: 0.6931471805599453

LOG10(): It returns the base-10 logarithm of a number.
Syntax: SELECT LOG(2);
Output: 0.6931471805599453

LOG2(): It returns the base-2 logarithm of a number.
Syntax: SELECT LOG2(6);
Output: 2.584962500721156

MOD(): It returns the remainder of n divided by m.
Syntax: SELECT MOD(18, 4);
Output: 2

PI(): It returns the value of PI displayed with 6 decimal places.
Syntax: SELECT PI();
Output: 3.141593

POW(): It returns m raised to the nth power.
Syntax: SELECT POW(4, 2);
Output: 16

RADIANS(): It converts a value in degrees to radians.
Syntax: SELECT RADIANS(180);
Output: 3.141592653589793

RAND(): It returns a random number.
Syntax: SELECT RAND();
Output: 0.33623238684258644

ROUND(): It returns a number rounded to a certain number of decimal places.
Syntax: SELECT ROUND(5.553);
Output: 6

SIGN(): It returns a value indicating the sign of a number.
Syntax: SELECT SIGN(255.5);
Output: 1

SIN(): It returns the sine of a number.
Syntax: SELECT SIN(2);
Output: 0.9092974268256817

SQRT(): It returns the square root of a number.
Syntax: SELECT SQRT(25);
Output: 5

TAN(): It returns the tangent of a number.
Syntax: SELECT TAN(1.75);
Output: -5.52037992250933

ATAN2(): It returns the arctangent of the x and y coordinates, as an angle and expressed in radians.
Syntax: SELECT ATAN2(7);
Output: 1.42889927219073

TRUNCATE(): It returns 7.53635 truncated to 2 places right of the decimal point.
Syntax: SELECT TRUNCATE(7.53635, 2);
Output: 7.53


---------------------------SQL | Numeric Functions-----------------------------





---------------------------SQL | String functions------------------------------


String functions
are used to perform an operation on input string and return an output string.
Following are the string functions defined in SQL:

ASCII(): This function is used to find the ASCII value of a character.
Syntax: SELECT ascii('t');
Output: 116
CHAR_LENGTH(): This function is used to find the length of a word.
Syntax: SELECT char_length('Hello!');
Output: 6
CHARACTER_LENGTH(): This function is used to find the length of a line.
Syntax: SELECT CHARACTER_LENGTH('geeks for geeks');
Output: 15
CONCAT(): This function is used to add two words or strings.
Syntax: SELECT 'Geeks' || ' ' || 'forGeeks' FROM dual;
Output: ‘GeeksforGeeks’
CONCAT_WS(): This function is used to add two words or strings with a symbol as concatenating symbol.
Syntax: SELECT CONCAT_WS('_', 'geeks', 'for', 'geeks');
Output: geeks_for_geeks
FIND_IN_SET(): This function is used to find a symbol from a set of symbols.
Syntax: SELECT FIND_IN_SET('b', 'a, b, c, d, e, f');
Output: 2
FORMAT(): This function is used to display a number in the given format.
Syntax: Format("0.981", "Percent");
Output: ‘98.10%’
INSERT(): This function is used to insert the data into a database.
Syntax: INSERT INTO database (geek_id, geek_name) VALUES (5000, 'abc');
Output: successfully updated
INSTR(): This function is used to find the occurrence of an alphabet.
Syntax: INSTR('geeks for geeks', 'e');
Output: 2 (the first occurrence of ‘e’)
Syntax: INSTR('geeks for geeks', 'e', 1, 2 );
Output: 3 (the second occurrence of ‘e’)
LCASE(): This function is used to convert the given string into lower case.
Syntax: LCASE ("GeeksFor Geeks To Learn");
Output: geeksforgeeks to learn
LEFT(): This function is used to SELECT a sub string from the left of given size or characters.
Syntax: SELECT LEFT('geeksforgeeks.org', 5);
Output: geeks
LENGTH(): This function is used to find the length of a word.
Syntax: LENGTH('GeeksForGeeks');
Output: 13
LOCATE(): This function is used to find the nth position of the given word in a string.
Syntax: SELECT LOCATE('for', 'geeksforgeeks', 1);
Output: 6
LOWER(): This function is used to convert the upper case string into lower case.
Syntax: SELECT LOWER('GEEKSFORGEEKS.ORG');
Output: geeksforgeeks.org
LPAD(): This function is used to make the given string of the given size by adding the given symbol.
Syntax: LPAD('geeks', 8, '0');
Output:
000geeks
LTRIM(): This function is used to cut the given sub string from the original string.
Syntax: LTRIM('123123geeks', '123');
Output: geeks
MID(): This function is to find a word from the given position and of the given size.
Syntax: Mid ("geeksforgeeks", 6, 2);
Output: for
POSITION(): This function is used to find position of the first occurrence of the given alphabet.
Syntax: SELECT POSITION('e' IN 'geeksforgeeks');
Output: 2
REPEAT(): This function is used to write the given string again and again till the number of times mentioned.
Syntax: SELECT REPEAT('geeks', 2);
Output: geeksgeeks
REPLACE(): This function is used to cut the given string by removing the given sub string.
Syntax: REPLACE('123geeks123', '123');
Output: geeks
REVERSE(): This function is used to reverse a string.
Syntax: SELECT REVERSE('geeksforgeeks.org');
Output: ‘gro.skeegrofskeeg’
RIGHT(): This function is used to SELECT a sub string from the right end of the given size.
Syntax: SELECT RIGHT('geeksforgeeks.org', 4);
Output: ‘.org’
RPAD(): This function is used to make the given string as long as the given size by adding the given symbol on the right.
Syntax: RPAD('geeks', 8, '0');
Output: ‘geeks000’
RTRIM(): This function is used to cut the given sub string from the original string.
Syntax: RTRIM('geeksxyxzyyy', 'xyz');
Output: ‘geeks’
SPACE(): This function is used to write the given number of spaces.
Syntax: SELECT SPACE(7);
Output: ‘       ‘
STRCMP(): This function is used to compare 2 strings.
If string1 and string2 are the same, the STRCMP function will return 0.
If string1 is smaller than string2, the STRCMP function will return -1.
If string1 is larger than string2, the STRCMP function will return 1.
Syntax: SELECT STRCMP('google.com', 'geeksforgeeks.com');
Output: -1
SUBSTR(): This function is used to find a sub string from the a string from the given position.
Syntax:SUBSTR('geeksforgeeks', 1, 5);
Output: ‘geeks’
SUBSTRING(): This function is used to find an alphabet from the mentioned size and the given string.
Syntax: SELECT SUBSTRING('GeeksForGeeks.org', 9, 1);
Output: ‘G’
SUBSTRING_INDEX(): This function is used to find a sub string before the given symbol.
Syntax: SELECT SUBSTRING_INDEX('www.geeksforgeeks.org', '.', 1);
Output: ‘www’
TRIM(): This function is used to cut the given symbol from the string.
Syntax: TRIM(LEADING '0' FROM '000123');
Output: 123
UCASE(): This function is used to make the string in upper case.
Syntax: UCASE ("GeeksForGeeks");
Output:
GEEKSFORGEEKS


----------------------------SQL | String functions------------------------------



-----------------------------SQL | Advanced Functions---------------------------

Following are some of the advanced functions defined in SQL:

BIN(): It converts a decimal number to a binary number.
Syntax:
SELECT BIN(18);
Output:


BINARY(): It converts a value to a binary string
Syntax:

SELECT BINARY "GeeksforGeeks";
Output:


COALESCE(): It returns the first non-null expression in a list.
Syntax:
SELECT COALESCE(NULL,NULL,'GeeksforGeeks',NULL,'Geeks');
Output:


CONNECTION_ID(): It returns the unique connection ID for the current connection.
Syntax:
SELECT CONNECTION_ID();
Output:


CURRENT_USER(): It returns the user name and host name for the MySQL account used by the server to authenticate the current client.
Syntax:
SELECT CURRENT_USER();
Output:


DATABASE(): It returns the name of the default database.
Syntax:
SELECT DATABASE();
Output:


IF(): It returns one value if a condition is TRUE, or another value if a condition is FALSE.
Syntax:
SELECT IF(200<500, "YES", "NO");
Output:


LAST_INSERT_ID(): It returns the first AUTO_INCREMENT value that was set by the most recent INSERT or UPDATE statement.
Syntax:
SELECT LAST_INSERT_ID();
Output:


NULLIF(): It Compares two expressions.
Syntax:
SELECT NULLIF(25.11, 25);
Output:


Syntax:
SELECT NULLIF(115, 115);
Output:


SESSION_USER(): It returns the user name and host name for the current MySQL user.
Syntax:
SELECT SESSION_USER();
Output:


SYSTEM_USER(): It returns the user name and host name for the current MySQL user.
Syntax:
SELECT SYSTEM_USER();
Output:


USER(): It returns the user name and host name for the current MySQL user.
Syntax:
SELECT USER();
Output:


VERSION(): It returns the version of the MySQL database.
Syntax:
SELECT VERSION();
Output:


-----------------------------SQL | Advanced Functions---------------------------




