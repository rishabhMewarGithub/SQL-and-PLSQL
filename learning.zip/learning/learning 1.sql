	
	
	
	CREATE OR REPLACE PROCEDURE CRD_OTR_TAB_REFRESH 	----creation and updation
	AS
	BEGIN
		DELETE FROM CRD.MV_CRD_OTR_VIEW ;
		COMMIT;

		INSERT INTO CRD.MV_CRD_OTR_VIEW
		
		
		
			
			SELECT ----
			FROM
				(

					SELECT 	DISTINCT 	xref.CUST_PO_NUMBER                    	AS	"PURCHASE ORDER NO",
										NULL                                   	AS 	"SHIPG DOC LI NBR", --rule for union all (data type should be same of corresponding columns)
										NVL(geae_om_util_pkg.get_segmented_dff_value('OTR Processing Attributes','GTA Validation Required',attribute3),'N') AS NJK
										'OU ID: '|| j.ou_id || '; ' || LOOKUP_CODE || ': ' || DESCRIPTION
										CRD_APP.CRD_COMMON_FUNCT_PKG.REPAIR_OTR_ENGINE_FAMILY_FUN(coli.ENG_MDL_NUMBER) 	AS 	"ENGINE FAMILY",  ---------- added by suvarna
										CRD_APP.CRD_COMMON_FUNCT_PKG.get_Customer_name_grp_New(coli.location_id,CRD_APP.CRD_COMMON_FUNCT_PKG.get_BILL_TO_NAME(coli.location_id)) AS "CUSTOMER NAME",
										DECODE	(	coli.location_id,'EV','ACSC')	AS 	"SHOP NAME",	
										DECODE	(	so.BAL_DUE_QTY,0,'CLOSED','OPEN') AS "PO LINE STATUS"
										DECODE	(	SUBSTR(so.esn_number,1,1),'0',	'`'||	so.esn_number,	so.esn_number) AS ESN,
										DECODE	(	so.rfqa_reqd_flg,'Y',	TO_CHAR(rfqa.rfqa_rcv_date,'DD-MON-YYYY')	) AS "DATE OF QUOTE APPROVAL",
										DECODE	(	coli.location_id, 'EV',
													DECODE	(	so.eng_mdl_number, '100','43', '107','45', '108','12', '109','29', '110','30', '112','31', '150','6', '214',
																'27', '373','20', '386','51', '101','4C', '370','49', '289','9B', '123','T7', '379','M0', '374','9X', '375',
																'9Z', '376','98', '116','F8', '121','P6', '361','X1', '112','31', '111','32', '356','14', '354','LG', '360',
																'F2', 'T58','58', '129','F9', '124','44',
																so.eng_mdl_number
															)
												)								AS "ENG_MDL_NUMBER",
										DECODE	(	so.eng_mdl_number, 'X1','GENX-1B',	'X2','GENX-2B',CRD_APP.CRD_COMMON_FUNCT_PKG.get_ENG_PL_NEW(coli.ENG_MDL_NUMBER)) AS "ENGINE MODEL",
										
										( 
											SELECT 	DISTINCT 	org_part_desc
											FROM 	crd_org_part
											WHERE 	part_number 	= coli.part_number
											AND 	org_id_num    	= 12
											AND 	location_id   	= 'EV'
										)                                       AS "PART DESCRIPTION",		
										
										TO_CHAR(coli.dock_date,'DD-MON-YYYY')   AS "DOCK DATE",
										TO_CHAR(co.csm_user_id_num)             AS 	"CSM ID#", -- added by suvarna
										TO_NUMBER(Tri.CUST_PO_LI_NUM) "PO LINE NO"
										TO_NUMBER(REPAIR_PO_SUMMARY_DETAILS_PKG.REPAIR_ATI_NSMR_QTY_FUN(Tri.cust_po_number))"QTY REJECTED"
										TO_NUMBER(nvl(LI.REPAIR_QUANTITY,0)*nvl(LI.LINE_PRICE,0)) "EXTENDED PRICE"
										ROUND( ( sysdate - coli.dock_date),0)     AS 	"SHOP ORDER AGE",
										(Tri.SCHEDULE_SHIP_DATE - Tri.create_date) "FORECAST TAT" --same format
										TO_CHAR(TO_DATE(Tri.MS_CREATE_DATE,'MM-DD-YYYY HH24:MI:SS'),'DD-MON-YYYY') "MS CREATE DATE"
										
										CASE
											WHEN coli.reqd_date	> to_date('31-DEC-2022','DD-MON-RRRR')
												THEN 	'`'	||	TO_CHAR(coli.reqd_date,'DD-MON-YYYY')
											ELSE 
												TO_CHAR(coli.reqd_date,'DD-MON-YYYY')
										END AS "REQD DATE",
											
										CASE
											WHEN rlsesch.schd_dlvry_date >= to_date('01-JAN-2100','DD-MON-YYYY')
												THEN 	NULL
											ELSE 	
												( rlsesch.schd_dlvry_date - coli.dock_date)
										END  AS "FORECAST TAT",
											
										
										
										
										
										
										/*END*/
					FROM 	CRD_SO 						so,
					
							(
								SELECT 	srl_number,
								FROM 	crd_ord_cmpnt_srl
								WHERE 	(ORD_CMPNT_ID,ord_comp_seq_num) IN
											(
												SELECT 	ORD_CMPNT_ID,
														MAX(ord_comp_seq_num)
												FROM 	crd_ord_cmpnt_srl
												WHERE 	location_id       		=	'EV'
												AND 	ord_cmpnt_cd        	=	'L'
												GROUP BY ORD_CMPNT_ID
											)
								AND 	location_id         	=	'EV'
							)	srl,
							
							(
								SELECT 	cmnt_txt,
										ORD_CMPNT_ID,
										ord_cmpnt_cstm_cmnt_sts_cd
								FROM 	CRD_ORD_CMPNT_CSTM_CMNT
								WHERE 	(ORD_CMPNT_ID,cmnt_seq_num) IN
											(
												SELECT 	ORD_CMPNT_ID,
														MAX(cmnt_seq_num)
												FROM 	CRD_ORD_CMPNT_CSTM_CMNT
												WHERE 	location_id	=	'EV'
												GROUP BY ORD_CMPNT_ID
											)
								AND location_id	=	'EV'
							)	cmnt,

					WHERE 	coli.CO_NUMBER                    	= so.ASM_CO_NUMBER
					AND 	coli.CO_LI_NUM                      = so.ASM_CO_LI_NUM
					AND 	Tri.create_date BETWEEN SYSDATE - 365 AND SYSDATE
					AND 	so.so_amdmt_num                     =	(
																		SELECT 	MAX(so_amdmt_num)
																		FROM 	crd_so so1
																		WHERE 	so1.asm_co_number IS NOT NULL
																		AND 	so1.AMDMT_STS_CD     = 'A'
																		AND 	so1.so_number        = so.so_number
																	)
					AND 	so.bal_due_qty               >	0
					AND 	coli.ref_id                  =	srl.ord_cmpnt_id(+)
					AND 	srl.ord_cmpnt_amdmt_num(+)   =	coli.amdmt_num
					AND 	rlsesch.location_id(+)       =	'EV' ---ask 
					AND 	rlse_sts_cd_num              = 	5
					AND 	so.create_date              <= SYSDATE
					AND 	coli.part_number 			NOT IN ('UNKNOWN' , 'UNK' , 'MISC')
					AND 	ord_cmpnt_cstm_cmnt_sts_cd(+)=	'A'
					
					AND 	(
								SELECT 	geae_cust_number
								FROM 	crd_cust_bill_to 	cb
								WHERE 	cb.cust_id_num       	=	coli.cust_id_num
								AND 	cb.bill_to_seq_num     	=	coli.bill_to_seq_num
							)	
							NOT IN	
							(	
								'56576','9573B', '9200M','9526B','9524B','9570B','9200A','9571B'
							)
					AND 	coli.eng_mdl_number 		NOT IN
														(	
															SELECT 	eng_mdl_number 
															FROM 	crd_eng_mdl 
															WHERE 	eng_prod_ln_scrubbed = 'APU'
														)
					AND 	coli.cmpnt_cd <>'UNK'														
					
					--------
					
					UNION ALL
					
					--SAME QUERY AS ABOVE
					
					
					
				)
				
				
			UNION ALL
				
				
			SELECT ----
			FROM	
				
				(
					-------------
					-------------
					
					
					UNION ALL
					
					-------------
					-------------
				
				)
			
			
			UNION ALL
			
			
			SELECT ----
			FROM	
				
				(
					-------------
					-------------
					
					
					UNION ALL
					
					-------------
					-------------
				
				)
				
			
			UNION ALL
			
			
			SELECT ----
			FROM	
				
				(
					-------------
					-------------
					
					
					UNION ALL
					
					-------------
					-------------
				
				)
				
				
			UNION ALL
			
			
			SELECT ----
			FROM	
				
				(
					-------------
					-------------
					
					
					UNION ALL
					
					-------------
					-------------
				
				)						;
			
		
		
		
		COMMIT;
		
	END;
	 
			
			
			
		
		
				
				