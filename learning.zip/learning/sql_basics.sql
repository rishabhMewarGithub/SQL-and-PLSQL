


Structured Query Language is a standard Database language which is 
used to create, maintain and retrieve the relational database.

SQL is the programming language for relational databases 
(explained below) like MySQL, Oracle, Sybase, SQL Server, Postgre, etc. 
Other non-relational databases (also called NoSQL) databases 
like MongoDB, DynamoDB, etc do not use SQL

----------------------------------------------------------------------

STUDENT

ROLL_NO		NAME		ADDRESS		PHONE			AGE
1			RAM			DELHI		9455123451		18
2			RAMESH		GURGAON		9652431543		18
3			SUJIT		ROHTAK		9156253131		20
4			SURESH		DELHI		9156768971		18

Table 1 shows the relational database with only one relation called 
STUDENT which stores ROLL_NO, NAME, ADDRESS, PHONE and AGE of students.

Attribute: Attributes are the properties that define a relation. 
e.g.; ROLL_NO, NAME etc.

Tuple: Each row in the relation is known as tuple. 
The above relation contains 4 tuples, one of which is shown as:

Degree: The number of attributes in the relation is known as 
degree of the relation. The STUDENT relation defined above has degree 5.

Cardinality: The number of tuples in a relation is known as cardinality. 
The STUDENT relation defined above has cardinality 4.

Column: Column represents the set of values for a particular attribute.
The column ROLL_NO is extracted from relation STUDENT.

-------------------------------------------------------------------------

Data Definition Language: It is used to define the structure of the 
database. e.g; CREATE TABLE, ADD COLUMN, DROP COLUMN and so on.

Data Manipulation Language: It is used to manipulate data in the 
relations. e.g.; INSERT, DELETE, UPDATE and so on.

Data Query Language: It is used to extract the data from the 
relations. e.g.; SELECT

SELECT [DISTINCT] Attribute_List 
FROM R1,R2….RM
[WHERE condition]
[GROUP BY (Attributes)[HAVING condition]]
[ORDER BY(Attributes)[DESC]];

--------------------------------------------------------------------------

example: If we want to represent the relation in ascending order by AGE, 
we can use ORDER BY clause as:
SELECT * FROM STUDENT ORDER BY AGE ASC;

example: If we want to retrieve distinct values of an attribute or group of attribute, 
DISTINCT is used as in:
SELECT DISTINCT ADDRESS FROM STUDENT;

--------------------------------------------------------------------------

AGGRATION FUNCTIONS: 
Aggregation functions are used to perform 
mathematical operations on data values of a relation. 
Some of the common aggregation functions used in SQL are:

1: COUNT: Count function is used to count the number of rows in a 
relation. e.g;
SELECT COUNT (PHONE) FROM STUDENT;

2: SUM: SUM function is used to add the values of an attribute in a 
relation. e.g;
SELECT SUM (AGE) FROM STUDENT;

3: MIN: MIN function is used to find minimum from the values of an 
attribute in a relation. e.g;
SELECT MIN (AGE) FROM STUDENT;

4: MAX: MAX function is used to find maximum from the values of an 
attribute in a relation. e.g;
SELECT MAX (AGE) FROM STUDENT;

5: AVG: AVG function is used to find average of the values of an 
attribute in a relation. e.g;
SELECT AVG (AGE) FROM STUDENT;

As we have seen above, all aggregation functions return only 1 row.

6: GROUP BY: Group by is used to group the tuples of a relation based 
on an attribute or group of attribute. It is always combined 
with aggregation function which is computed on group. e.g.;
SELECT 	ADDRESS, SUM(AGE) FROM STUDENT	GROUP BY (ADDRESS);

NOTE: If we try to execute the query given below, it will result in 
error because although we have computed SUM(AGE) for each address, 
there are more than one ROLL_NO for  each address we have grouped. 
SELECT ROLL_NO, ADDRESS, SUM(AGE) FROM STUDENT	GROUP BY (ADDRESS); 

NOTE: NOTE: An attribute which is not a part of GROUP BY clause can’t 
be used for selection. Any attribute which is part of GROUP BY CLAUSE 
can be used for selection but it is not mandatory.

-------------------------------------------------------------------------

DATA TYPES:

1. Binary Datatypes :
binary			
varbinary		
varbinary(max)	
image		

2. Exact Numeric Datatype :
bigint
int
smallint
tinyint
bit
decimal
numeric
money
smallmoney

3. Approximate Numeric Datatype :
float
real

4. Character String Datatype :
char
varchar
varchar(max)
text

5. Unicode Character String Datatype :
nchar
Nvarchar
nvarchar(max)

6. Date and Time Datatype :
datetime
smalldatetime
date
time

------------------------------------------------------------------------

DDL (Data Definition Language):

CREATE	: to create objects in database
ALTER	: alters the structure of database
DROP	: delete objects from database
RENAME	: rename an objects
TRUNCATE
COMMENT

------------------------------------------------------------------------

DML (Data Manipulation Language) :

SELECT: retrieve data from the database
INSERT: insert data into a table
UPDATE: update existing data within a table
DELETE: deletes all records from a table, space for the records remain

------------------------------------------------------------------------

TCL (Transaction Control Language) :

COMMIT: Commit command is used to permanently save any transaction
        into the database.
ROLLBACK: This command restores the database to last committed state.
          It is also used with savepoint command to jump to a savepoint
          in a transaction.
SAVEPOINT: Savepoint command is used to temporarily save a transaction so
           that you can rollback to that point whenever necessary.

------------------------------------------------------------------------

DCL (Data Control Language) :

GRANT: allow specified users to perform specified tasks.
REVOKE: cancel previously granted or denied permissions.

------------------------------------------------------------------------

SQL TRANSACTIONS:

--It is important to note that these statements cannot be used while creating tables and are only used with the DML Commands such as – INSERT, UPDATE and DELETE.

1: SET TRANSACTION: Places a name on a transaction.
SET TRANSACTION [ READ WRITE | READ ONLY ];

2: COMMIT: 
COMMIT;
DELETE FROM Student WHERE AGE = 20;
COMMIT;

3: ROLLBACK: 
ROLLBACK;
DELETE FROM Student WHERE AGE = 20;
ROLLBACK;

4: SAVEPOINT: --creates points within the groups of transactions in which to ROLLBACK.
SAVEPOINT SAVEPOINT_NAME;
ROLLBACK TO SAVEPOINT_NAME;
example:
SAVEPOINT SP1;
//Savepoint created.
DELETE FROM Student WHERE AGE = 20;
//deleted
SAVEPOINT SP2;
//Savepoint created.

--Deletion have been taken place, let us assume that you have changed your mind and decided to ROLLBACK to the SAVEPOINT that you 
--identified as SP1 which is before deletion. deletion is undone by this statement ,
ROLLBACK TO SP1;
//Rollback completed.
--Notice that first deletion took place even though you rolled back to SP1 which is first SAVEPOINT.

5: RELEASE SAVEPOINT:- --This command is used to remove a SAVEPOINT that you have created.
RELEASE SAVEPOINT SAVEPOINT_NAME

-------------------------------------------------------------------------

VIEW:

Views in SQL are kind of virtual tables. A view also has rows and 
columns as they are in a real table in the database. We can create 
a view by selecting fields from one or more tables present in the 
database. A View can either have all the rows of a table or specific 
rows based on certain condition.

-------

We can create View using CREATE VIEW statement. A View can be created 
from a single table or multiple tables.

CREATE VIEW view_name AS
SELECT column1, column2.....
FROM table_name
WHERE condition;

view_name: Name for the View
table_name: Name of the table
condition: Condition to select rows

example:
CREATE VIEW DetailsView AS
SELECT NAME, ADDRESS
FROM StudentDetails
WHERE S_ID < 5;
SELECT * FROM DetailsView;

example:
CREATE VIEW StudentNames AS
SELECT S_ID, NAME
FROM StudentDetails
ORDER BY NAME;
SELECT * FROM StudentNames;

example:
CREATE VIEW MarksView AS
SELECT StudentDetails.NAME, StudentDetails.ADDRESS, 
	   StudentMarks.MARKS
FROM StudentDetails, StudentMarks
WHERE StudentDetails.NAME = StudentMarks.NAME;
SELECT * FROM MarksView;

-------

We can delete or drop a View using the DROP statement.

DROP VIEW view_name;
view_name: Name of the View which we want to delete.
example:
DROP VIEW MarksView;

-------

There are certain conditions needed to be satisfied to update a view. 
If any one of these conditions is not met, then we will not be allowed 
to update the view.
a: The SELECT statement which is used to create the view should not 
include GROUP BY clause or ORDER BY clause.
b: The SELECT statement should not have the DISTINCT keyword.
c: The View should have all NOT NULL values.
d: The view should not be created using nested queries or complex 
queries.
e: The view should be created from a single table. If the view is 
created using multiple tables then we will not be allowed to update the view.

We can use the CREATE OR REPLACE VIEW statement to add or remove 
fields from a view.
Syntax:
CREATE OR REPLACE VIEW view_name AS
SELECT column1,coulmn2,..
FROM table_name
WHERE condition;

For example, if we want to update the view MarksView and add the 
field AGE to this View from StudentMarks Table, we can do this as:
CREATE OR REPLACE VIEW MarksView AS
SELECT StudentDetails.NAME, StudentDetails.ADDRESS, 
       StudentMarks.MARKS, StudentMarks.AGE
FROM StudentDetails, StudentMarks
WHERE StudentDetails.NAME = StudentMarks.NAME;
SELECT * FROM MarksView;

--------

We can insert a row in a View in a same way as we do in a table. 
We can use the INSERT INTO statement of SQL to insert a row in a View.
INSERT view_name(column1, column2 , column3,..) 
VALUES(value1, value2, value3..);
view_name: Name of the View

example:
In the below example we will insert a new row in the View DetailsView 
which we have created above in the example of “creating views from a 
single table”.
INSERT INTO DetailsView(NAME, ADDRESS)
VALUES("Suresh","Gurgaon");
SELECT * FROM DetailsView;

--------

Deleting rows from a view is also as simple as deleting rows from a 
table. We can use the DELETE statement of SQL to delete rows from a 
view. 
Also deleting a row from a view first delete the row from the 
actual table and the change is then reflected in the view.
DELETE FROM view_name
WHERE condition;
view_name:Name of view from where we want to delete rows
condition: Condition to select rows 

example:
In this example we will delete the last row from the view 
DetailsView which we just added in the above example of inserting 
rows.
DELETE FROM DetailsView
WHERE NAME="Suresh";
SELECT * FROM DetailsView;

---------

The WITH CHECK OPTION clause is used to prevent the insertion of rows 
in the view where the condition in the WHERE clause in CREATE VIEW 
statement is not satisfied.
If we have used the WITH CHECK OPTION clause in the CREATE VIEW 
statement, and if the UPDATE or INSERT clause does not satisfy the 
conditions then they will return an error.

CREATE VIEW SampleView AS
SELECT S_ID, NAME
FROM  StudentDetails
WHERE NAME IS NOT NULL
WITH CHECK OPTION;

In this View if we now try to insert a new row with null value in the 
NAME column then it will give an error because the view is created 
with the condition for NAME column as NOT NULL.
For example,though the View is updatable but then also the below query 
for this View is not valid:
INSERT INTO SampleView(S_ID)
VALUES(6);

-------------------------------------------------------------------------

CONSTRAINTS:

Constraints are the rules that we can apply on the type of data in a 
table. That is, we can specify the limit on the type of data that 
can be stored in a particular column in a table using constraints.

The available constraints in SQL are:

NOT NULL: This constraint tells that we cannot store a null value in a 
column. That is, if a column is specified as NOT NULL then we will 
not be able to store null in this particular column any more.

UNIQUE: This constraint when specified with a column, tells that 
all the values in the column must be unique. That is, the values in 
any row of a column must not be repeated.

PRIMARY KEY: A primary key is a field which can uniquely identify 
each row in a table. And this constraint is used to specify a field 
in a table as primary key.

FOREIGN KEY: A Foreign key is a field which can uniquely identify 
each row in a another table. And this constraint is used to specify a 
field as Foreign key.

CHECK: This constraint helps to validate the values of a column to 
meet a particular condition. That is, it helps to ensure that the 
value stored in a column meets a specific condition.

DEFAULT: This constraint specifies a default value for the column 
when no value is specified by the user.

CREATE TABLE sample_table
(
column1 data_type(size) constraint_name,
column2 data_type(size) constraint_name,
column3 data_type(size) constraint_name,
....
);
sample_table: Name of the table to be created.
data_type: Type of data that can be stored in the field.
constraint_name: Name of the constraint. for example- 
NOT NULL, UNIQUE, PRIMARY KEY etc.

CREATE TABLE Student
(
ID int(6) NOT NULL,
NAME varchar(10) NOT NULL,
ADDRESS varchar(20)
);

CREATE TABLE Student
(
ID int(6) NOT NULL UNIQUE,
NAME varchar(10),
ADDRESS varchar(20)
);

CREATE TABLE Student
(
ID int(6) NOT NULL UNIQUE,
NAME varchar(10),
ADDRESS varchar(20),
PRIMARY KEY(ID)
);

CREATE TABLE Orders
(
O_ID int NOT NULL,
ORDER_NO int NOT NULL,
C_ID int,
PRIMARY KEY (O_ID),
FOREIGN KEY (C_ID) REFERENCES Customers(C_ID)
);

CREATE TABLE Student
(
ID int(6) NOT NULL,
NAME varchar(10) NOT NULL,
AGE int NOT NULL CHECK (AGE >= 18)
);

CREATE TABLE Student
(
ID int(6) NOT NULL,
NAME varchar(10) NOT NULL,
AGE int DEFAULT 18
);

UNIQUE:

Evaluates to true on an empty sub query.
Returns true only if there are unique tuples present as the output 
of the sub query (two tuples are unique if the value of any attribute 
of the two tuples differ).
Returns true if the sub query has two duplicate rows with at least 
one attribute as NULL.
SELECT table.ID
FROM  table
WHERE UNIQUE (SELECT table2.ID FROM table2 WHERE table.ID = table2.ID);

During the execution, first the outer query is evaluated to obtain 
table.ID. 
Following this, the inner sub query is processed which 
produces a new relation that contains the output of inner query such 
that table.ID == table2.ID. 
If every row in the new relation is unique then unique returns true 
and the corresponding table.ID is added as a tuple in the output 
relation produced. 
However, if every row in the new relation is not unique then unique 
evaluates to false and the corresponding table.ID is not add to the 
output relation.
Unique applied to a sub query return false if and only if there are 
two tuples t1 and t2 such that t1 = t2. 
It considers t1 and t2 to be 
two different tuple, when unique is applied to a sub query that 
contains t1 and t2 such that t1 = t2 and at least one of the attribute 
of these tuples contains a NULL value. 
Unique predicate in this case evaluates to true. 
This is because, a NULL value in SQL is treated as an unknown value 
therefore, two NULL values are considered to be distinct.

The SQL statement without UNIQUE clause can also be written as:
SELECT table.ID
FROM  table
WHERE 1 <= (SELECT count(table2.ID) FROM table2 WHERE table.ID = table2.ID);
			  
EXAMPLE:
EMPLOYEEID	NAME	COURSEID	YEAR
77505		Alan	SC110		2017
77815		Will	CSE774		2017
85019		Smith	EE457		2017
92701		Sam		PYS504		2017
60215		Harold	HSS103		2016
77505		Alan	BIO775		2017
92701		Sam		ECO980		2017

Find all the instructors that taught at most one course in the 
year 2017.
SELECT I.EMPLOYEEID, I.NAME
FROM Instructor as I
WHERE UNIQUE (SELECT Inst.EMPLOYEEID
              FROM Instructor as Inst
              WHERE I.EMPLOYEEID = Inst.EMPLOYEEID
                          and Inst.YEAR = 2017);

EXAMPLE:
COURSEID	NAME				DEPARTMENT			INSTRUCTORID
CSE505		Computer Network	Computer Science	11071
CSE245		Operating System	Computer Science	74505
CSE101		Programming			Computer Science	12715
HSS505		Psychology			Social Science		85017
EE475		Signals & Systems	Electrical			22150
CSE314		DBMS				Computer Science	44704
CSE505		Computer Network	Computer Science	11747
CSE314		DBMS				Computer Science	44715

Find all the courses in Computer Science department that has only a 
single instructor allotted to that course.
SELECT C.COURSEID, C.NAME
FROM Course as C
WHERE UNIQUE (SELECT T.INSTRUCTORID
              FROM Course as T
              WHERE T.COURSEID = C.COURSEID 
                          and C.DEPARTMENT = 'Computer Science');
						  
CHECK:

CREATE TABLE pets(
        ID INT NOT NULL,
        Name VARCHAR(30) NOT NULL,
        Breed VARCHAR(20) NOT NULL,
        Age INT,
        GENDER VARCHAR(9),
        PRIMARY KEY(ID),
        check(GENDER in ('Male', 'Female', 'Unknown'))
        );
		
Different options to use Check constraint:

With alter: Check constraint can also be added to an already 
created relation using the syntax:
alter table TABLE_NAME modify COLUMN_NAME check(Predicate);

Giving variable name to check constraint: Check constraints can be 
given a variable name using the syntax:
alter table TABLE_NAME add constraint CHECK_CONST check (Predicate);

Remove check constraint: Check constraint can be removed from the 
relation in the database from SQL server using the syntax:
alter table TABLE_NAME drop constraint CHECK_CONSTRAINT_NAME;

Drop check constraint: Check constraint can be dropped from the 
relation in the database in MySQL using the syntax:
alter table TABLE_NAME drop check CHECK_CONSTRAINT_NAME;

---------------------------------------------------------------------

CREATING ROLES

A role is created to ease setup and maintenance of the security model. 
It is a named group of related privileges that can be granted to the 
user. When there are many users in a database it becomes difficult to 
grant or revoke privileges to users. Therefore, if you define roles:

You can grant or revoke privileges to users, thereby automatically 
granting or revoking privileges.
You can either create Roles or use the system roles pre-defined.

Some of the privileges granted to the system roles are as given below:
SYSTEM ROLES	PRIVILEGES GRANTED TO THE ROLE
Connect			Create table, Create view, Create synonym, 
				Create sequence, Create session etc.
Resource		Create Procedure, Create Sequence, Create Table, 
				Create Trigger etc. 
				The primary usage of the Resource role is to 
				restrict access to database objects.
DBA				All system privileges

Creating and Assigning a Role –
First, the (Database Administrator)DBA must create the role. 
Then the DBA can assign privileges to the role and users to the role.

Syntax –
CREATE ROLE manager;
Role created.
In the syntax:
‘manager’ is the name of the role to be created.

Now that the role is created, the DBA can use the GRANT statement to 
assign users to the role as well as assign privileges to the role.
It’s easier to GRANT or REVOKE privileges to the users through a 
role rather than assigning a privilege directly to every user.
If a role is identified by a password, then GRANT or REVOKE 
privileges have to be identified by the password.

Grant privileges to a role –
GRANT create table, create view
TO manager;
Grant succeeded.

Grant a role to users-
GRANT manager TO SAM, STARK;
Grant succeeded.

Revoke privilege from a Role-
REVOKE create table FROM manager;

Drop a Role-
DROP ROLE manager;

Explanation –
Firstly it creates a manager role and then allows managers to 
create tables and views. It then grants Sam and Stark the role of 
managers. Now Sam and Stark can create tables and views. If users 
have multiple roles granted to them, they receive all of the 
privileges associated with all of the roles. Then create table 
privilege is removed from role ‘manager’ using Revoke.The role 
is dropped from the database using drop.

---------------------------------------------------------------------

INDEXES:

















































































