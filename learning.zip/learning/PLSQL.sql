

-----------------------------------PL/SQL BLOCK BEGINS--------------------------------------

--PL/SQL code to print sum of two numbers taken from the user. 
SQL> SET SERVEROUTPUT ON; 

SQL> DECLARE 
	-- only declaration
	var1 INTEGER; 
    var2 REAL; 
    var3 varchar2(20) ; 
	-- initializing variables
	var4 INTEGER := 2 ; 
    var5 varchar2(20) := 'I Love GeeksForGeeks' ; 
	-- taking input for variable a 
	a integer := &a ; 
	-- taking input for variable b 
	b integer := &b ; 
	c integer ; 
BEGIN 
	c := a + b ; 
	dbms_output.put_line('Sum of '||a||' and '||b||' is = '||c);
	dbms_output.put_line(var5); 	
END; 
/ 

-----------------------------------PL/SQL BLOCK ENDS--------------------------------------




-----------------------------------PL/SQL CURSOR BEGINS--------------------------------------

DECLARE variables;
		records;
create a cursor;
BEGIN 
	OPEN cursor; 
	FETCH cursor;
		process the records;
	CLOSE cursor; 
END;

-----------------------------------PL/SQL CURSOR ENDS--------------------------------------




-----------------------------------PL/SQL SUM OF TWO NUMBERS BEGINS--------------------------------------
declare
-- declare variable x, y and z of datatype number 
x number(5);			 
y number(5);			 
z number(7);		 

begin
	-- Here we Assigning 10 into x 
	x:=10;				 
	-- Assigning 20 into x 
	y:=20;				 
	-- Assigning sum of x and y into z 
	z:=x+y;				 
	// Print the Result 
	dbms_output.put_line('Sum is '||z); 
end; 
/						 
-- Program End 

-----------------------------------PL/SQL SUM OF TWO NUMBERS ENDS--------------------------------------




-----------------------------------PL/SQL REVERSE A NUMBER BEGINS--------------------------------------

declare
-- declare variable num , len and revnum of datatype varchar 
num varchar2(5):='12345';			 
len number(2);			 
revnum varchar2(5);		 

begin
	-- Here we find the length of string 
	len := length(num);				 
	-- here we starting a loop from max len to 1 
	for i in reverse 1.. len 
	loop 
		-- assigning the reverse number in revnum			 
		revnum := revnum || substr(num,i,1); 
	end loop; 
	-- Print the Result 
	dbms_output.put_line('given number ='|| num); 
	dbms_output.put_line('reverse number ='|| revnum); 
end;						 
-- Program End 

-----------------------------------PL/SQL REVERSE A NUMBER ENDS--------------------------------------




-----------------------------------PL/SQL FACTORIAL OF A NUMBER BEGINS--------------------------------------

declare
-- declare variable num , fact and temp of datatype number 
num number := 6;			 
fact number := 1;			 
temp number;		 

begin
	temp :=num; 
	-- here we check condition with the help of while loop 
	while( temp>0 )			 
	loop 
		fact := fact*temp; 
		temp := temp-1; 
	end loop; 
	dbms_output.put_line('factorial of '|| num || ' is ' || fact); 
end; 					
-- Program End 

-----------------------------------PL/SQL FACTORIAL OF A NUMBER ENDS--------------------------------------





-----------------------------------PL/SQL PRINT PATTERNS BEGINS--------------------------------------

declare
-- declare variable n, i and j of datatype number 
n number := 7; 
i number; 
j number; 

begin
	-- loop from 1 to n 
	for i in 1..n 
	loop 
		for j in 1..i 
		loop 
			-- printing * 
			dbms_output.put('*'); 
		end loop; 
		-- for new line 
		dbms_output.new_line; 
	end loop; 
end; 
--Program End 

-----------------------------------PL/SQL PRINT PATTERNS ENDS--------------------------------------





-----------------------------------PL/SQL IF-THEN STATEMENT BEGINS--------------------------------------

if condition then
-- do something
end if;

---------------------------------

declare
-- declare the values here 
begin
	if condition then
		dbms_output.put_line('output'); 
	end if; 
	dbms_output.put_line('output2'); 
end; 

----------------------------------

-- pl/sql program to illustrate If statement 
declare
num1 number:= 10; 
num2 number:= 20; 
begin
	if num1 > num2 then
		dbms_output.put_line('num1 small'); 
	end if; 
	dbms_output.put_line('I am Not in if'); 
end; 

-----------------------------------PL/SQL IF-THEN STATEMENT ENDS--------------------------------------




-----------------------------------PL/SQL IF-THEN-ELSE STATEMENT BEGINS--------------------------------------

if (condition) then
    -- Executes this block if
    -- condition is true
else 
    -- Executes this block if
    -- condition is false
	
----------------------------------

-- pl/sql program to illustrate If else statement 
declare
num1 number:= 10; 
num2 number:= 20; 
begin
	if num1 < num2 then
		dbms_output.put_line('i am in if block'); 
	ELSE
		dbms_output.put_line('i am in else Block'); 
	end if; 
	dbms_output.put_line('i am not in if or else Block'); 
end; 

-----------------------------------PL/SQL IF-THEN-ELSE STATEMENT ENDS--------------------------------------




-----------------------------------PL/SQL NESTED-IF-THEN STATEMENT BEGINS--------------------------------------

if (condition1) then
   -- Executes when condition1 is true
   if (condition2) then 
     -- Executes when condition2 is true
   end if; 
end if;

----------------------------------

-- pl/sql program to illustrate nested If statement 
declare
num1 number:= 10; 
num2 number:= 20; 
num3 number:= 20; 
begin
	if num1 < num2 then
		dbms_output.put_line('num1 small num2'); 
		if num1 < num3 then
			dbms_output.put_line('num1 small num3 also'); 
		end if; 
	end if; 
	dbms_output.put_line('after end if'); 
end; 

-----------------------------------PL/SQL NESTED-IF-THEN STATEMENT ENDS--------------------------------------




-----------------------------------PL/SQL IF-THEN-ELSIF-THEN-ELSE LADDER STATEMENT BEGINS--------------------------------------

if (condition) then
    --statement
elsif (condition) then
    --statement
.
.
else
    --statement
endif

----------------------------------

-- pl/sql program to illustrate if-then-elif-then-else ladder 
declare
num1 number:= 10; 
num2 number:= 20; 
begin
	if num1 < num2 then
		dbms_output.put_line('num1 small'); 
	ELSIF num1 = num2 then
		dbms_output.put_line('both equal'); 
	ELSE
		dbms_output.put_line('num2 greater'); 
	end if; 
	dbms_output.put_line('after end if'); 
end; 

-----------------------------------PL/SQL IF-THEN-ELSIF-THEN-ELSE LADDER STATEMENT ENDS--------------------------------------




-----------------------------------PSEUDOCOLUMN IN ORACLE SQL BEGINS-----------------------------------

Pseudocolumn in Oracle SQL
Pseudocolumn: A pseudo-column behaves like a table column but is not actually stored in the table. You can select from pseudo-columns, 
but you cannot insert, update, or delete their values. A pseudo-column is also similar to a function without arguments. 
This section describes these pseudo-columns:
	CURRVAL and NEXTVAL
	LEVEL
	ROWID
	ROWNUM

CURRVAL and NEXTVAL: A sequence is a schema object that can generate unique sequential values. These values are often used for primary and 
unique keys. You can refer to sequence values in SQL statements with these pseudocolumns:
	CURRVAL : Returns the current value of a sequence.
	NEXTVAL : Increments the sequence and returns the next value.
	Examples:
		SELECT STUDENTSEQ.currval FROM DUAL;
		INSERT INTO STUDENT VALUES (STUDENTSEQ.nextval, ‘BISHAL’, ‘JAVA’, 7902);
LEVEL: For each row returned by a hierarchical query, the LEVEL pseudocolumn returns 1 for a root node, 2 for a child of a root, and so on.
ROWNUM: Oracle engine maintains the number of each record inserted by users in table. By the help of ROWNUM clause we can access the data according to the record inserted.
	Example:
		SELECT * FROM EMP WHERE ROWNUM <= 3;
ROWID: For each row in the database, the ROWID pseudocolumn returns a row\’s address. The ROWID contains 3 information about row address:
	FileNo : FileNo means Table Number.
	DataBlockNo : DataBlockNo means the space assigned by the oracle sql engine to save the record.
	RecordNo : Oracle engine mantains the record number for each record.
	Example:
		SELECT ROWID, ename FROM emp WHERE deptno = 20;

-----------------------------------PSEUDOCOLUMN IN ORACLE SQL ENDS-----------------------------------





--------------------------------------------------------PL/SQL PROCEDURE BEGINS--------------------------------------------------------


---------------------------Syntax to create a stored procedure BEGINS---------------------------

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- Comments --
CREATE PROCEDURE procedure_name
  = ,
  = ,
  = 
AS
BEGIN
-- Query --
END
GO

------------------------------------------------------------------

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE GetStudentDetails
    @StudentID int = 0
AS
BEGIN
    SET NOCOUNT ON;
    SELECT FirstName, LastName, BirthDate, City, Country
    FROM Students WHERE StudentID=@StudentID
END
GO

---------------------------Syntax to create a stored procedure ENDS-----------------------------

---------------------------Syntax to modify an existing stored procedure BEGINS-----------------

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- Comments --
ALTER PROCEDURE procedure_name
  = ,
  = ,
  = 
AS
BEGIN
-- Query --
END
GO

------------------------------------------------------------------

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
ALTER PROCEDURE GetStudentDetails
      @StudentID int = 0
AS
BEGIN
      SET NOCOUNT ON;
      SELECT FirstName, LastName, City
      FROM Students WHERE StudentID=@StudentID
END
GO

---------------------------Syntax to modify an existing stored procedure ENDS-------------------

---------------------------Syntax to drop a Procedure BEGINS------------------------------------

DROP PROCEDURE procedure_name
------------------------------------------------------------------
DROP PROCEDURE GetStudentDetails

---------------------------Syntax to drop a Procedure ENDS--------------------------------------


----------------------------------------------------------PL/SQL PROCEDURE ENDS----------------------------------------------------------





-------------------------------------------PRINT DIFFERENT STAR PATTERNS IN SQL BEGINS---------------------------------------------------

Declare @variable_name DATATYPE     -- first declare all the variables with datatype like (int)
select @variable = WITH_ANY_VALUE   -- select the variable and initialize with value
while CONDITION                     -- condition like @variable > 0 
begin                               -- begin
	print replicate('*', @variable) -- replicate insert the * character in variable times
	set increment/decrement         -- in increment/decrement @variable= @variable+1
END                                 -- end while loop

--------------------------------------------------------------------------------------------

* * * * *
* * * * 
* * * 
* * 
*

DECLARE @var int			 -- Declare 
SELECT @var = 5			 -- Initialization 
WHILE @var > 0				 -- condition 
BEGIN						 -- Begin 
PRINT replicate('* ', @var) -- Print 
SET @var = @var - 1		 -- decrement 
END						 -- END 

--------------------------------------------------------------------------------------------

*
* *
* * *
* * * *
* * * * *

DECLARE @var int				 -- Declare 
SELECT @var = 1				 -- initialization 
WHILE @var <= 5				 -- Condition 
BEGIN							 -- Begin 
PRINT replicate('* ', @var)	 -- Print 
SET @var = @var + 1			 -- Set 
END							 -- end 

--------------------------------------------------------------------------------------------

    *
   **
  ***
 ****
*****

DECLARE @var int, @x int				 -- declare two variable 
SELECT @var = 4,@x = 1				 -- initialization 
WHILE @x <=5							 -- condition 
BEGIN
PRINT space(@var) + replicate('*', @x) -- here space for 
										-- create spaces 
SET @var = @var - 1					 -- set 
set @x = @x + 1						 -- set 
END									 -- End 

--------------------------------------------------------------------------------------------

*****
 ****
  ***
   **
    *
	
DECLARE @var int, @x int				 -- declare two variable 
SELECT @var = 0,@x = 5				 -- initialization 
WHILE @x > 0							 -- condition 
BEGIN
PRINT space(@var) + replicate('*', @x) -- here space for 
										-- create spaces 
SET @var = @var + 1					 -- set 
set @x = @x - 1						 -- set 
END									 -- End 

-------------------------------------------PRINT DIFFERENT STAR PATTERNS IN SQL ENDS---------------------------------------------------



-------------------------------------------PL/SQL GCD OF TWO NUMBERS BEGINS---------------------------------------------------

DECLARE
	-- declare variable num1, num2 and t and these three variables datatype are integer 
	num1 INTEGER; 
	num2 INTEGER; 
	t INTEGER; 
BEGIN
	num1 := 8; 
	num2 := 48; 
	WHILE MOD(num2, num1) != 0 
	LOOP 
		t := MOD(num2, num1); 
		num2 := num1; 
		num1 := t; 
	END LOOP; 
	dbms_output.Put_line('GCD of '||num1 ||' and '||num2 ||' is '||num1); 
END; 
-- Program End 

-------------------------------------------PL/SQL GCD OF TWO NUMBERS ENDS---------------------------------------------------




-------------------------------------------PL/SQL CENTERED TRIANGULAR NUMBER BEGINS---------------------------------------------------

-- declaration section 
DECLARE
x NUMBER; 
n NUMBER; 

--utility function 
FUNCTION Centered_triangular_num(n IN NUMBER) 
	RETURN NUMBER 
IS
	z NUMBER; 
BEGIN
	--formula applying 
	z := (3 * n * n + 3 * n + 2) / 2; 
	RETURN z; 
END; 
--driver code 
BEGIN
	n := 3; 
	x := centered_triangular_num(n); 
	dbms_output.Put_line(x); 
	n := 12; 
	x := centered_trigunal_num(n); 
	dbms_output.Put_line(x); 
END; 
--End of program 

-------------------------------------------PL/SQL CENTERED TRIANGULAR NUMBER ENDS---------------------------------------------------














































































