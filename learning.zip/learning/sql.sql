
SELECT [DISTINCT] Attribute_List 
FROM R1,R2….RM
[WHERE condition]
[GROUP BY (Attributes)[HAVING condition]]
[ORDER BY(Attributes)[DESC]];
----------------------------------------------------------------------------
CREATE DATABASE database_name;
create table table_name(column1 char(20),column2 char(15),column3 numeric(12,2));
-----
CREATE TABLE newTable LIKE pets
CREATE TABLE newTable as(SELECT * FROM pets WHERE pets.BREED = 'German Shepherd')
----------------------------------------------------------------------------
DROP object object_name
DROP TABLE table_name;
DROP DATABASE database_name;
TRUNCATE TABLE  table_name;
Table or Database deletion using DROP statement cannot be rolled back, so it must be used wisely.
DELETE FROM table_name WHERE some_condition;
UPDATE table_name SET column1 = value1, column2 = value2,... WHERE condition;
-----
ALTER TABLE table_name RENAME TO new_table_name;
ALTER TABLE table_name RENAME COLUMN old_name TO new_name;
ALTER TABLE table_name ADD (Columnname_1  datatype,Columnname_2  datatype, …Columnname_n  datatype);
ALTER TABLE table_name DROP COLUMN column_name;
ALTER TABLE table_name MODIFY column_name column_type;
-----

------------------------------------------------------------------------------------------------------------------------------------------
SELECT * FROM table_name ORDER BY column_name ASC|DESC
SELECT * FROM table_name ORDER BY column1 ASC|DESC , column2 ASC|DESC
ASC is the default value for ORDER BY clause
-----
SELECT column1, colomn2, … FROM table_name WHERE NOT condition;
SELECT Fname, Lname FROM Emplyoee WHERE Salary NOT BETWEEN 30000 AND 45000;
-----
SELECT DISTINCT column1,column2 FROM table_name 
select table_name.column1 FROM table_name where table_name.column2 = 'value';
-----
SELECT column1, function_name(column2) FROM table_name WHERE condition GROUP BY column1, column2 ORDER BY column1, column2;
SELECT 	column1, SUM(column2) FROM table_name GROUP BY (column1);
SELECT column1, column2, Count(*) FROM table_name GROUP BY column1, column2;
SELECT column1, function_name(column2) FROM table_name WHERE condition GROUP BY column1, column2 HAVING condition ORDER BY column1, column2;
SELECT NAME, SUM(SALARY) FROM Employee  GROUP BY NAME HAVING SUM(SALARY)>3000; 
-----
SELECT * FROM table_name WHERE condition1 AND condition2 and ...conditionN;
SELECT * FROM table_name WHERE condition1 OR condition2 OR... conditionN;
SELECT * FROM table_name WHERE condition1 AND (condition2 OR condition3);
-----
SELECT TOP value column1,column2 FROM table_name;
SELECT TOP value PERCENT column1,column2 FROM table_name;
SELECT column1,column2 FROM table_name LIMIT value;
SELECT column1,column2 FROM table_name WHERE ROWNUM <= value;
-----
SELECT column1,column2 FROM table_name WHERE column_name operator value;
SELECT column1,column2 FROM table_name WHERE column_name BETWEEN value1 AND value2;
SELECT column1,column2 FROM table_name WHERE column_name LIKE pattern;
SELECT column1,column2 FROM table_name WHERE column_name IN (value1,value2,..);
-----
SELECT column_name(s)  FROM table_name WHERE EXISTS (SELECT column_name(s) FROM table_name WHERE condition);
It can be used in a SELECT, UPDATE, INSERT or DELETE statement.
-----
SELECT column1 as alias_name1,column2 as alias_name2 FROM table_name;
SELECT column FROM table_name as alias_name;
SELECT s.column_name1, d.column_name1 FROM table_name1 AS s, table_name2 AS d WHERE s.column_name2=20 AND s.column_name3=d.column_name3; 
-----
SELECT column_name(s) FROM table1 WHERE condition UNION SELECT column_name(s) FROM table2 WHERE condition;
SELECT column_name(s) FROM table1 WHERE condition UNION ALL SELECT column_name(s) FROM table2 WHERE condition;
The column names in both the select statements can be different but the data type must be same.And in the result set the name of column 
used in the first select statement will appear. 
-----
SELECT table1.column1,table1.column2,table2.column1,....FROM table1 INNER JOIN table2 ON table1.matching_column = table2.matching_column;
SELECT table1.column1,table1.column2,table2.column1,....FROM table1, table2 where table1.matching_column = table2.matching_column;
SELECT StudentCourse.COURSE_ID, Student.NAME, Student.AGE FROM Student INNER JOIN StudentCourse ON Student.ROLL_NO = StudentCourse.ROLL_NO;
SELECT table1.column1,table1.column2,table2.column1,....FROM table1 LEFT JOIN table2 ON table1.matching_column = table2.matching_column;
SELECT Student.NAME,StudentCourse.COURSE_ID FROM Student LEFT JOIN StudentCourse ON StudentCourse.ROLL_NO = Student.ROLL_NO;
SELECT table1.column1,table1.column2,table2.column1,....FROM table1 RIGHT JOIN table2 ON table1.matching_column = table2.matching_column;
SELECT Student.NAME,StudentCourse.COURSE_ID FROM Student RIGHT JOIN StudentCourse ON StudentCourse.ROLL_NO = Student.ROLL_NO;
SELECT table1.column1,table1.column2,table2.column1,....FROM table1 FULL JOIN table2 ON table1.matching_column = table2.matching_column;
SELECT Student.NAME,StudentCourse.COURSE_ID FROM Student FULL JOIN StudentCourse ON StudentCourse.ROLL_NO = Student.ROLL_NO;
SELECT table1.column1 , table1.column2, table2.column1...FROM table1 CROSS JOIN table2;
SELECT Student.NAME, Student.AGE, StudentCourse.COURSE_ID FROM Student CROSS JOIN StudentCourse;
SELECT a.coulmn1 , b.column2 FROM table_name a, table_name b WHERE some_condition;
SELECT a.ROLL_NO , b.NAME FROM Student a, Student b WHERE a.ROLL_NO < b.ROLL_NO;
-----
SELECT id, first_name, last_name, first_name || last_name, salary, first_name || salary FROM myTable
SELECT id, first_name, last_name, salary, first_name||' has salary '||salary as "new"  FROM myTable
SELECT id, first_name, last_name, salary, first_name||100||' has id '||id AS "new" FROM myTable
SELECT id, first_name, last_name, salary,first_name||q'{ has salary's }'||salary AS "new" FROM myTable
--SELECT id, name, dept, name||q'[ work’s in ‘]’||dept||’department’ AS “work” FROM myTable2
-----
SELECT column1 , column2 , ... columnN FROM table_name WHERE condition MINUS SELECT column1 , column2 , ... columnN FROM table_name WHERE condition;
SELECT ALL field_name FROM table_name WHERE condition(s);
SELECT column_name(s) FROM table_name WHERE column_name comparison_operator ALL (SELECT column_name FROM table_name WHERE condition(s));
SELECT ProductName FROM Products WHERE ProductID = ALL (SELECT ProductId FROM OrderDetails WHERE Quantity = 6 OR Quantity = 2);
SELECT OrderID FROM OrderDetails GROUP BY OrderID HAVING max(Quantity) > ALL (SELECT avg(Quantity) FROM OrderDetails GROUP BY OrderID);
SELECT column_name(s)FROM table_name WHERE column_name comparison_operator ANY (SELECT column_name FROM table_name WHERE condition(s));
SELECT DISTINCT CategoryID FROM Products WHERE ProductID = ANY (SELECT ProductID FROM OrderDetails);
SELECT ProductName FROM Products WHERE ProductID = ANY (SELECT ProductID FROM OrderDetails WHERE Quantity = 9);
------
-----------------------------------------------------------------------------------------------------------------------------------------
SELECT COUNT (column1) FROM table_name;
SELECT SUM (column1) FROM table_name;
SELECT MIN (column1) FROM table_name;
SELECT MAX (column1) FROM table_name;
SELECT AVG (column1) FROM table_name;
----------------------------------------------------------------------------
INSERT INTO table_name VALUES (value1, value2, value3,…);
INSERT INTO table_name (column1, column2, column3,..) VALUES ( value1, value2, value3,..);
INSERT INTO first_table SELECT * FROM second_table;
INSERT INTO first_table(names_of_columns1) SELECT names_of_columns2 FROM second_table;
INSERT INTO table1 SELECT * FROM table2 WHERE condition;
----------------------------------------------------------------------------
SELECT column1, column2, column3, column3 + 100 AS "column3 + 100" FROM table_name;
SELECT column1, column2, column3, column3 + column1 AS "column3 + column1" FROM table_name;
SELECT column1, column2, column3, column3 - 100 AS "column3 - 100" FROM table_name;
SELECT column1, column2, column3, column3 - column1 AS "column3 - column1" FROM table_name;
SELECT column1, column2, column3, column3 * 100 AS "column3 * 100" FROM table_name;
SELECT column1, column2, column3, column3 * column1 AS "column3 * column1" FROM table_name;
SELECT column1, column2, column3, column3 % 100 AS "column3 % 100" FROM table_name;
SELECT column1, column2, column3, column3 % column1 AS "column3 % column1" FROM table_name;
SELECT column1, column2, column3, type, type + 100 AS "type+100" FROM addition;
Make sure that NULL is unavailable, unassigned, unknown. Null is not same as blank space or zero.
-----
SELECT * FROM Student ORDER BY Grade DESC LIMIT 3;
SELECT * FROM Student LIMIT 5 OFFSET 2 ORDER BY ROLLNO;
SELECT * FROM Student LIMIT ALL;
-----
SELECT column_name(s) FROM table_name WHERE expression comparison_operator SOME (subquery)
SELECT column-1, column-2 …… FROM table 1 WHERE…... INTERSECT SELECT column-1, column-2 …… FROM table 2 WHERE…...
SELECT ID, Name, Bonus FROM table1  LEFT JOIN table2 ON table1.ID = table2.Employee_ID INTERSECT SELECT ID, Name, Bonus FROM table1  RIGHT JOIN table2 ON table1.ID = table2.Employee_ID;
SELECT column-1, column-2 …… FROM table 1 WHERE….. EXCEPT SELECT column-1, column-2 ……  FROM table 2 WHERE…..

----------------------------------------------------------------------------
SET TRANSACTION [ READ WRITE | READ ONLY ];
-----
COMMIT;
DELETE FROM table_name WHERE column1 = 'value';
COMMIT;
-----
ROLLBACK;
DELETE FROM table_name WHERE column1 = 'value';
ROLLBACK;
-----
SAVEPOINT SAVEPOINT_NAME;
ROLLBACK TO SAVEPOINT_NAME;
-----
example:
SAVEPOINT SP1;
//Savepoint created.
DELETE FROM table_name WHERE column1 = 'value';
//deleted
SAVEPOINT SP2;
//Savepoint created.
-----
ROLLBACK TO SP1;
//Rollback completed.
-----
RELEASE SAVEPOINT SAVEPOINT_NAME
----------------------------------------------------------------------------------------------------------
CREATE VIEW view_name AS SELECT column1, column2.....FROM table_name WHERE condition ORDER BY column1;
CREATE VIEW view_name AS SELECT table_name_1.column1, table_name_1.column2, table_name_2.column1 FROM table_name_1, table_name_2 WHERE table_name_1.column1 = table_name_2.column1;
DROP VIEW view_name;
CREATE OR REPLACE VIEW view_name AS SELECT column1,coulmn2,.. FROM table_name WHERE condition;
CREATE OR REPLACE VIEW view_name AS SELECT table_name_1.column1, table_name_1.column2, table_name_2.column1 FROM table_name_1, table_name_2 WHERE table_name_1.column1 = table_name_2.column1;
INSERT view_name(column1, column2 , column3,..) VALUES(value1, value2, value3..);
DELETE FROM view_name WHERE condition;
CREATE VIEW view_name AS SELECT column1, column2.....FROM  table_name WHERE column1 IS NOT NULL WITH CHECK OPTION;
----------------------------------------------------------------------------------------------------------
CREATE TABLE table_name_1
(
column1 data_type(size) NOT NULL UNIQUE,
column2 data_type(size) constraint_name,
column3 data_type(size) NOT NULL CHECK (GENDER in ('Male', 'Female', 'Unknown')),
column4 data_type(size) DEFAULT 18
....
PRIMARY KEY (column1),
FOREIGN KEY (column2) REFERENCES table_name_2(column2)
);
----------------------------------------------------------------------------------------------------------
SELECT table_name_1.column1 FROM  table_name_1 WHERE UNIQUE (SELECT table_name_2.column1 FROM table_name_2 WHERE table_name_1.column1 = table_name_2.column1);
-------
SELECT table_name_1.column1 FROM  table_name_1 WHERE 1 <= (SELECT count(table_name_2.column1) FROM table_name_2 WHERE table_name_1.column1 = table_name_2.column1);
-------
EXAMPLE:
EMPLOYEEID	NAME	COURSEID	YEAR
77505		Alan	SC110		2017
77815		Will	CSE774		2017
85019		Smith	EE457		2017
92701		Sam		PYS504		2017
60215		Harold	HSS103		2016
77505		Alan	BIO775		2017
92701		Sam		ECO980		2017
Find all the instructors that taught at most one course in the year 2017.
SELECT I.EMPLOYEEID, I.NAME FROM Instructor as I WHERE UNIQUE (SELECT Inst.EMPLOYEEID FROM Instructor as Inst WHERE I.EMPLOYEEID = Inst.EMPLOYEEID and Inst.YEAR = 2017);
--------
EXAMPLE:
COURSEID	NAME				DEPARTMENT			INSTRUCTORID
CSE505		Computer Network	Computer Science	11071
CSE245		Operating System	Computer Science	74505
CSE101		Programming			Computer Science	12715
HSS505		Psychology			Social Science		85017
EE475		Signals & Systems	Electrical			22150
CSE314		DBMS				Computer Science	44704
CSE505		Computer Network	Computer Science	11747
CSE314		DBMS				Computer Science	44715
Find all the courses in Computer Science department that has only a single instructor allotted to that course.
SELECT C.COURSEID, C.NAME FROM Course as C WHERE UNIQUE (SELECT T.INSTRUCTORID FROM Course as T WHERE T.COURSEID = C.COURSEID and C.DEPARTMENT = 'Computer Science');
----------------------------------------------------------------------------------------------------------------------------------------
alter table TABLE_NAME modify COLUMN_NAME check(Predicate);
alter table TABLE_NAME add constraint CHECK_CONST check (Predicate);
alter table TABLE_NAME drop constraint CHECK_CONSTRAINT_NAME;
alter table TABLE_NAME drop check CHECK_CONSTRAINT_NAME;
-----------------------------------------------------------------------------------------------------------------------------------------



